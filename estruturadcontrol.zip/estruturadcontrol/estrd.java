class estrd{

    public static void main(String[] args) {

        int opcao;
        String result;
        opcao = 3;

        switch(opcao) {
            case 1:
                result = "Opção 1";
                break;
                case 2:
                result = "Opção 2";
                break;
                case 3:
                result = "Opção 3";
                break;
                case 4:
                result = "Opção 4";
                break;
                case 5:
                result = "Opção 5";   
                break;
                default:
                result = "opção inválida";
                break;
        }

        System.out.println("Opção escolhida "+result);

    }
}