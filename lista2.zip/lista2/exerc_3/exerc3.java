import java.util.Scanner;

class exerc3{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int a;
        int b;
        int c;

        System.out.print("Informe o primeiro valor: ");
        a =s.nextInt();

        System.out.print("Informe o segundo valor; ");
        b =s.nextInt();

        System.out.print("Informe o terceiro valor: ");
        c =s.nextInt();

        if(a < b && a < b) {
            if(b < c){
                System.out.println(a+", "+b+", "+c);
            }
            else{
                System.out.println(a+", "+c+", "+b);
            }
        }
        else if(b<a && b<c){
            if(a<c){
                System.out.println(b+", "+a+", "+c);
            }
            else{
                System.out.println(b+", "+c+", "+a);
            }
        }
        else{
            if(a<b){
                System.out.println(c+", "+a+", "+b);
            }
            else{
                System.out.println(c+", "+b+", "+a);
            }
        }

        s.close();
        
    }
}
