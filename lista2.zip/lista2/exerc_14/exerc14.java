import java.util.Scanner;

class exerc14{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        /*Imagine uma brincadeira entre dois colegas onde um fornece um número e o outro deve adivinhar qual é.
        Como dica, indique se o chute dado foi alto ou baixo em relação ao número escolhido.
        Pode sortear um número aleatório também. (repita)*/

        int num;
        int chute;

        System.out.print("informe um numero: ");
        num =s.nextInt();

        while(true){
            System.out.print("qual o numero? ");
            chute =s.nextInt();
            if(chute<num){
                System.out.println("O numero é maior");
            }
            else if(chute>num){
                System.out.println("O numero é menor");
            }
            else if(chute == num){
                System.out.println("Você acertou");
                break;
            }
            else{
                System.out.println("Erro: valor inválido");
            }
        }
        s.close();

    }
}