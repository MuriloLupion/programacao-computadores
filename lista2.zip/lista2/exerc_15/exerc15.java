class exerc15{

    public static void main(String[] args){

        /*Elabore um algoritmo que simule uma contagem regressiva de 10 minutos,
        ou seja, mostre 10:00, 9:59, 9:58 até 0:00. (para)*/

        for(int min=10; min>=0; min--){
            int seginicial = (min==10) ? 0 : 59;
            for(int seg=seginicial; seg>=0; seg--){
                System.out.printf("%02d:%02d\n", min, seg);
            }
        }
        
    }
}