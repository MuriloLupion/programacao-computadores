import java.util.Scanner;

class exerc12{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int num1;
        int num2;

        System.out.print("Informe o primeiro número: ");
        num1 =s.nextInt();

        System.out.print("Informe o segundo número: ");
        num2 =s.nextInt();

        System.out.println("Valores entre "+num1+" e "+num2+": ");

        if(num1<num2){
            for(int i = num1 + 1; i < num2; i++){
        System.out.println(i);
        }
        }
        else if(num1>num2){
            for(int i = num1 - 1; i > num2; i--){
            System.out.println(i);
            }
        }
        else{
            System.out.println("informe valores válidos");
        }
        s.close();

    }
}