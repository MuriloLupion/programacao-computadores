import java.util.Scanner

class exerc5{

    public static void main
}