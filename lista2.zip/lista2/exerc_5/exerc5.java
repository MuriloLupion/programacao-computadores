import java.util.Scanner;

class exerc5{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int nasc;

        System.out.print("Informe seu ano de nascimento: ");
        nasc =s.nextInt();

        int calc = 2025 - nasc;

        if(calc>=18){
            System.out.println("Pode votar e tirar carteira");
        }
        else if(calc<16){
            System.out.println("não pode nem votar nem tirar carteira");
        }
        else{
            System.out.println("Pode somente votar");
        }

        s.close();

    }
}