import java.util.Scanner;

class exerc6{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        /*Faça um algoritmo que receba dois valores e um operador aritmético (+, -, /, * - adição, subtração, divisão e multiplicação).
        Caso o símbolo seja outro, informe “Símbolo inválido”. Faça o cálculo conforme o operador informado e exiba a expressão e o resultado. */

        int vlr1;
        int vlr2;
        char operador;
        int calc;

        System.out.print("Informe o primeiro valor: ");
        vlr1 =s.nextInt();

        System.out.print("Informe um operador aritmético(+, -, /, *): ");
        operador =s.next().charAt(0);

        System.out.print("Informe o segundo valor: ");
        vlr2 =s.nextInt();

    }
}