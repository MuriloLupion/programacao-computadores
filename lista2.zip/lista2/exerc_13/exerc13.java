import java.util.Scanner;

class exerc13{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        /*Construa um algoritmo que calcule a soma de números pares que o usuário informar enquanto ele não digitar zero.
        O usuário pode informar qualquer número entre 0 e 100, mas só deve ser somado se ele for par. Encerrar o laço quando
        o usuário digitar 0. */

        int num1;
        int soma = 0;

        System.out.println("digite números de 0 a 100");

        while(true){
            System.out.print("digite um número: ");
        num1 =s.nextInt();
        if(num1 == 0){
        break;
        }
        if(num1>=0 && num1<=100){
            if(num1 % 2 ==0){
                soma+=num1;
            }
        }
        else{
            System.out.println("número invalido");
        }
    }
        System.out.println("resultado: "+soma);
        s.close();

    }
}
