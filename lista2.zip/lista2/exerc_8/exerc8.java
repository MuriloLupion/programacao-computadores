import java.util.Scanner;

class exerc8{

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);

        int idade;

        System.out.print("informe sua idade: ");
        idade =s.nextInt();

        if(idade >=5 && idade <=7){
            System.out.println("categoria infantil A");
        }
        else if(idade >=8 && idade <=10){
            System.out.println("categoria infantil B");
        }
        else if(idade >=11 && idade <=13){
            System.out.println("categoria juvenil A");
        }
        else if(idade >=14 && idade <=17){
            System.out.println("categoria juvenil B");
        }
        else if(idade >=18){
            System.out.println("categoria adulto");
        }
        else{
            System.out.println("informe um valor valido");
        }
        s.close();

    }
}
