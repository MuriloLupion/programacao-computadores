import java.util.Scanner;

class exemplo_operadores{

    public static void main(String[] args) {
        
        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        double divisao;
        double resto_divisao;
        boolean menor_que;
        boolean maior_que;

        Scanner s = new Scanner(System.in); //variável para ler informações do terminal(entrada de dados)
        
        System.out.println("Informe os valores inteiro para:");
        System.out.print("A: ");
        A = s.nextInt();

        System.out.print("B: ");
        B = s.nextInt();

        

        soma = A + B;
        subtracao = A - B;
        multiplicacao = A * B;
        divisao = A / B;
        resto_divisao = A % B;
        menor_que = A<B;
        maior_que = A>B;
        boolean maior_que_soma = soma>50;
        boolean menor_que_soma = soma<50;
        boolean par = divisao%2==0;
        double test = divisao%2;



        System.out.println("O resultado das operacoes a e b:");
        System.out.println("A="+A+"\nB="+B);
        System.out.println("soma:"+soma);
        System.out.println("subtracao:"+subtracao);
        System.out.println("multiplicacao:"+multiplicacao);
        System.out.println("divisao:"+divisao);
        System.out.println("resto da divisao:"+resto_divisao);

        System.out.println ("E que menor que ?"+" "+menor_que);
        System.out.println ("E Maior Que?"+" "+maior_que);
        System.out.println ("E maior que 50?"+" "+maior_que_soma);
        System.out.println ("E Menor que 50?"+" "+menor_que_soma);
        System.out.println ("O numero e par?"+" "+par);
        System.out.println ("Test = "+test);

        //criar variáveis para cada tipo primitivo, peça ao usuário os valores, armazene nas variáveis e depois mostre na tela os valores informados pelo usuário:

        int ex_inteiro;
        char ex_char;
        double ex_double;
        boolean ex_boolean;
        String ex_String;


        System.out.print("informe um valor inteiro para: ");
        ex_inteiro =s.nextInt();
        System.out.println("Valor informado: "+ex_inteiro);

        System.out.print("informe um unico valor individual para: ");
        ex_char =s.next().charAt(0); //index é a posição do elemento
        System.out.println("Valor informado: "+ex_char);

        System.out.print("informe um valor para: ");
        ex_double =s.nextDouble();
        System.out.println("Valor informado: "+ex_double);

        System.out.print("informa true ou false: ");
        ex_boolean =s.nextBoolean();
        System.out.println("valor informado: "+ex_boolean);

        System.out.print("informe seu nome: ");
        ex_String =s.next();
        System.out.println("Valor informado: "+ex_String);


    }

}