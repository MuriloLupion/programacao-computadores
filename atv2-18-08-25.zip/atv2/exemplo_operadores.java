class exemplo_operadores{

    public static void main(String[] args) {
        
        int A;
        int B;

        int soma;
        int subtracao;
        int multiplicacao;
        double divisao;
        double resto_divisao;

        A = 10;
        B = 3;

        soma = A + B;
        subtracao = A - B;
        multiplicacao = A * B;
        divisao = A / B;
        resto_divisao = A % B;

        System.out.println("O resultado das operacoes a e b:");
        System.out.println("A="+A+"\nB="+B);
        System.out.println("soma:"+soma);
        System.out.println("subtracao:"+subtracao);
        System.out.println("multiplicacao:"+multiplicacao);
        System.out.println("divisao:"+divisao);
        System.out.println("resto da divisao:"+resto_divisao);

    }

}