import java.util.Scanner;

class arquivo{

    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);

        int ladoA;
        int ladoB;
        int ladoC;

        System.out.print("Informe o primeiro lado do triângulo: ");
        ladoA =s.nextInt();

        System.out.print("Informe o segundo lado do triângulo: ");
        ladoB =s.nextInt();

        System.out.print("Informe o terceiro lado do triângulo: ");
        ladoC =s.nextInt();

        if (ladoA == ladoB && ladoB == ladoC) {
            System.out.println("O triãngulo é equilatero");
        }
        else if(ladoA == ladoB || ladoA == ladoC || ladoB == ladoC) {
            System.out.println("O triângulo é isóceles");
        }
        else{
            System.out.println("O triângulo é escaleno");
        }
        
        s.close();

    }
}