public class exWhile {

    public static void main(String[] args){

        int cont;
        cont = 0;

        while (cont < 5) {
            System.out.println("Contador com while: "+cont);
            //cont++;
            cont = cont + 1;
        }
        do{
            System.out.println("Contador com do: "+cont);
            cont++;
        } while (cont<5);

    }
}