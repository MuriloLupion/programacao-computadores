import java.util.Scanner;

class exerc8{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        int num1;
        int num30;

        System.out.print("informe o valor do relógio de água do 1 dia dos mês: ");
        num1 =s.nextInt();

        System.out.print("infoem o valor do relógio de água do 30 dia dos mês: ");
        num30 =s.nextInt();

        int result = num30 - num1;

        System.out.println("foram consumidos " + result);

        s.close();

    }
}