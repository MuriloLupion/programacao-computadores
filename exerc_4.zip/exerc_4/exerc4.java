import java.util.Scanner;

class exerc4{

    public static void main(String[] args) {
    
        Scanner s = new Scanner(System.in);

        int num1;
        int num2;

        System.out.print("Infome o primeiro número inteiro: ");
        num1 =s.nextInt();

        System.out.print("Informe o segundo número inteiro: ");
        num2 =s.nextInt();

        if(num1 == num2) {
            System.out.println("Os números são iguais");
        }
        else if(num1 > num2) {
            System.out.println("O primeiro número é maior que o segundo");
        }
        else{
            System.out.println("O primeiro número é menor que o segundo");
        }

        s.close();

    }

}